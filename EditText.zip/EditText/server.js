const express = require('express');
const app = express();
const port = process.env.PORT || 3000;
let titles = {};

app.use(express.json());
app.use(express.static('public')); // Sert les fichiers statiques (HTML, CSS, JS)

app.post('/save-titles', (req, res) => {
    try {
        const { content, titles: newTitles } = req.body;
        titles = newTitles; // Sauvegarde les titres
        res.json({ message: 'Titres sauvegardés avec succès' });
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors de la sauvegarde des titres' });
    }
});

app.get('/load-titles', (req, res) => {
    try {
        res.json(titles);
    } catch (error) {
        res.status(500).json({ error: 'Erreur lors du chargement des titres' });
    }
});

app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
