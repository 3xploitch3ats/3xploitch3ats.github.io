const WebSocket = require('ws');
const express = require('express');
const http = require('http');

// Create an Express application
const app = express();
const server = http.createServer(app);

// Create a WebSocket server
const wss = new WebSocket.Server({ server });

// Track connected users
const users = new Map(); // Maps WebSocket to username
const userConnections = new Map(); // Maps username to WebSocket connection

// Broadcast the updated user list
const broadcastUserList = () => {
    const userList = Array.from(users.values());
    const userListMessage = JSON.stringify({ type: 'userList', users: userList });
    wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(userListMessage);
        }
    });
};

// Handle WebSocket connections
wss.on('connection', (ws) => {
    console.log('New client connected');

    // Send current user list on new connection
    broadcastUserList();

    // Handle incoming messages
    ws.on('message', (message) => {
        const msg = JSON.parse(message);

        if (msg.type === 'setUsername') {
            // Update the username for the WebSocket connection
            users.set(ws, msg.username);
            userConnections.set(msg.username, ws);
            broadcastUserList();
        } else if (msg.type === 'message') {
            // Broadcast message to all users
            wss.clients.forEach((client) => {
                if (client.readyState === WebSocket.OPEN) {
                    client.send(JSON.stringify({
                        type: 'message',
                        content: msg.content,
                        sender: users.get(ws)
                    }));
                }
            });
        } else if (msg.type === 'like' || msg.type === 'unlike') {
            // Handle likes and unlikes
            const senderId = users.get(ws);
            const receiverWs = userConnections.get(msg.peerId);

            if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                receiverWs.send(JSON.stringify({
                    type: msg.type,
                    senderId: senderId
                }));
            }
        } else if (msg.type === 'notification') {
            // Send notifications to specific users
            const receiverWs = userConnections.get(msg.peerId);

            if (receiverWs && receiverWs.readyState === WebSocket.OPEN) {
                receiverWs.send(JSON.stringify({
                    type: 'notification',
                    content: msg.content
                }));
            }
        }
    });

    // Handle user disconnection
    ws.on('close', () => {
        console.log('Client disconnected');
        const username = users.get(ws);
        users.delete(ws);
        userConnections.delete(username);
        broadcastUserList();
    });
});

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Start the server
const port = process.env.PORT || 3000;
server.listen(port, () => {
    console.log(`Server is listening on port ${port}`);
});
