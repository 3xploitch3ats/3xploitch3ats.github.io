const express = require('express');
const fs = require('fs');
const path = require('path');
const fetch = require('node-fetch');
const unzipper = require('unzipper');

const app = express();
const PORT = process.env.PORT || 3000;
const { exec } = require('child_process');

// Serve static files
app.use(express.static(path.join(__dirname, 'public')));


// Endpoint to check if phpMyAdmin directory exists
app.get('/check', (req, res) => {
    const phpMyAdminPath = path.join(__dirname, 'phpmyadmin');
    res.json({ exists: fs.existsSync(phpMyAdminPath) });
});
// Route principale
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});
// Endpoint to check if index.php exists in the phpMyAdmin directory
app.get('/check-index', (req, res) => {
    const phpMyAdminIndexPath = path.join(__dirname, 'public', 'phpmyadmin', 'index.php');
    
    fs.access(phpMyAdminIndexPath, fs.constants.F_OK, (err) => {
        if (err) {
            res.status(404).send('index.php not found');
        } else {
            // Execute PHP script
            exec(`php ${phpMyAdminIndexPath}`, (error, stdout, stderr) => {
                if (error) {
                    res.status(500).send(`Error executing PHP: ${stderr}`);
                } else {
                    // Set the Content-Type header to text/html
                    res.set('Content-Type', 'text/html');
                    res.send(stdout);
                }
            });
        }
    });
});

// Endpoint to download phpMyAdmin
app.get('/download', async (req, res) => {
    const url = 'https://github.com/phpmyadmin/phpmyadmin/archive/RELEASE_5_2_1.zip';
    const zipPath = path.join(__dirname, 'phpmyadmin.zip');

    try {
        const response = await fetch(url);
        if (!response.ok) throw new Error(`Failed to fetch: ${response.statusText}`);

        const fileStream = fs.createWriteStream(zipPath);
        response.body.pipe(fileStream);

        const contentLength = response.headers.get('Content-Length');
        let downloaded = 0;

        response.body.on('data', chunk => {
            downloaded += chunk.length;
            if (contentLength) {
                const progress = (downloaded / contentLength) * 100;
                // Send progress update to client
                res.write(`data: ${JSON.stringify({ progress: progress.toFixed(2) })}\n\n`);
            }
        });

        fileStream.on('finish', () => {
            res.end();
        });

        response.body.on('error', (err) => {
            console.error('Download error:', err);
            res.status(500).send('Download failed');
        });

        fileStream.on('error', (err) => {
            console.error('File write error:', err);
            res.status(500).send('Error writing file');
        });

    } catch (error) {
        console.error('Error downloading phpMyAdmin:', error);
        res.status(500).send('Error downloading phpMyAdmin');
    }
});

// Endpoint to unzip the downloaded file
app.get('/unzip', (req, res) => {
    const zipPath = path.join(__dirname, 'phpmyadmin.zip');
    const extractPath = path.join(__dirname, 'phpmyadmin');

    fs.createReadStream(zipPath)
        .pipe(unzipper.Extract({ path: extractPath }))
        .on('close', () => {
            fs.unlink(zipPath, (err) => {
                if (err) console.error('Error deleting zip file:', err);
            });
            res.status(200).send();
        })
        .on('error', (err) => {
            console.error('Unzip error:', err);
            res.status(500).send('Unzip failed');
        });
});

// Route to handle moving files into phpMyAdmin
app.post('/move', (req, res) => {
    const releasePath = path.join(__dirname, 'phpmyadmin', 'phpmyadmin-RELEASE_5_2_1');
    const phpMyAdminPath = path.join(__dirname, 'phpmyadmin');

    if (!fs.existsSync(releasePath)) {
        return res.status(404).send('Release directory not found');
    }

    fs.readdir(releasePath, (err, files) => {
        if (err) return res.status(500).send('Error reading release directory');

        if (!fs.existsSync(phpMyAdminPath)) {
            fs.mkdirSync(phpMyAdminPath, { recursive: true });
        }

        files.forEach(file => {
            const srcPath = path.join(releasePath, file);
            const destPath = path.join(phpMyAdminPath, file);

            fs.rename(srcPath, destPath, (err) => {
                if (err) return res.status(500).send('Error moving file: ' + file);
            });
        });

        fs.rmdir(releasePath, (err) => {
            if (err) console.error('Error deleting release folder:', err);
        });

        // Move phpmyadmin folder into public
        const publicPhpMyAdminPath = path.join(__dirname, 'public', 'phpmyadmin');
        fs.rename(phpMyAdminPath, publicPhpMyAdminPath, (err) => {
            if (err) return res.status(500).send('Error moving phpmyadmin to public folder: ' + err);
            
            res.status(200).send('Files moved and phpMyAdmin folder relocated successfully');
        });
    });
});
// Route to handle the deletion of the phpMyAdmin directory
app.delete('/delete', (req, res) => {
    const phpMyAdminPath = path.join(__dirname, 'phpmyadmin');
    const zipPath = path.join(__dirname, 'phpmyadmin.zip');
        if (fs.existsSync(zipPath)) {
            fs.unlink(zipPath, (err) => {
                if (err) console.error('Error deleting zip file:', err);
            });
        }
    fs.rm(phpMyAdminPath, { recursive: true, force: true }, (err) => {
        if (err) {
            console.error('Error deleting phpMyAdmin:', err);
            return res.status(500).send('Error deleting phpMyAdmin');
        }

        res.send('phpMyAdmin deleted successfully');
    });
});
// Endpoint to check if index.php exists in the phpMyAdmin directory
app.get('/check-index', (req, res) => {
    const phpMyAdminIndexPath = path.join(__dirname, 'phpmyadmin', 'index.php');
    fs.access(phpMyAdminIndexPath, fs.constants.F_OK, (err) => {
        if (err) {
            res.status(404).send('index.php not found');
        } else {
            res.status(200).send('index.php exists');
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
