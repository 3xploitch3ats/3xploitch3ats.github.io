const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const formidable = require('formidable');

const app = express();
const uploadDir = path.join(__dirname, 'public/uploads');

// Middleware to handle CORS
app.use(cors({
    origin: '*', // Permet toutes les origines ; ajustez selon vos besoins
    methods: 'GET, POST, PUT, DELETE, OPTIONS',
    allowedHeaders: 'Content-Type, Authorization',
    credentials: true // Permet l'utilisation des cookies
}));

// Middleware to serve static files
app.use(express.static(path.join(__dirname, 'public')));

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
    fs.mkdirSync(uploadDir, { recursive: true });
}

// Function to sanitize the file name
function sanitizeFileName(fileName) {
    return fileName.replace(/\s+/g, '_'); // Remplace les espaces par des underscores
}

app.post('/upload', (req, res) => {
    const form = new formidable.IncomingForm();
    form.uploadDir = uploadDir;
    form.keepExtensions = true;

    form.parse(req, (err, fields, files) => {
        if (err) {
            console.error('Error parsing form:', err);
            res.status(500).send('Server error');
            return;
        }

        if (!files.file || !files.file.filepath) {
            res.status(400).send('No file uploaded.');
            return;
        }

        // Retrieve the original file name or use the name assigned during upload
        const originalFileName = files.file.originalFilename || path.basename(files.file.filepath);
        const sanitizedFileName = sanitizeFileName(originalFileName);
        const fileUrl = `/uploads/${sanitizedFileName}`;

        // Rename the file to the sanitized name
        fs.rename(files.file.filepath, path.join(uploadDir, sanitizedFileName), (err) => {
            if (err) {
                console.error('Error renaming file:', err);
                res.status(500).send('Server error');
                return;
            }
            
            res.status(200).json({ fileUrl });
        });
    });
});

// Handle 405 Method Not Allowed
app.use((req, res) => {
    res.status(405).send('Method Not Allowed');
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
