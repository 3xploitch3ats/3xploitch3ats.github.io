const express = require('express');
const puppeteer = require('puppeteer');
const cors = require('cors');

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.static('public'));

app.get('/api/asteroids', async (req, res) => {
  try {
    const browser = await puppeteer.launch({
      headless: true,
      args: ['--no-sandbox']
    });

    const page = await browser.newPage();

    // Bloquer images, polices, CSS pour accélérer
    await page.setRequestInterception(true);
    page.on('request', (req) => {
      const type = req.resourceType();
      if (['image', 'stylesheet', 'font'].includes(type)) {
        req.abort();
      } else {
        req.continue();
      }
    });

    // Chargement rapide (sans attendre tout le réseau)
    await page.goto('https://fr.wikipedia.org/wiki/Ast%C3%A9ro%C3%AFde_g%C3%A9ocroiseur#Liste_partielle_d%27objets_num%C3%A9rot%C3%A9s', {
      waitUntil: 'domcontentloaded'
    });

    const asteroids = await page.evaluate(() => {
      const asteroidsList = [];
      const links = document.querySelectorAll('div.colonnes a');
      links.forEach(link => {
        const name = link.textContent;
        const url = link.href;
        asteroidsList.push({ name, url });
      });
      return asteroidsList;
    });

    await browser.close();

    // Envoi progressif par chunks (ex: 50 par 50)
    res.setHeader('Content-Type', 'application/json');
    res.write('['); // début du tableau JSON

    const chunkSize = 50;
    for (let i = 0; i < asteroids.length; i += chunkSize) {
      const chunk = asteroids.slice(i, i + chunkSize);
      res.write(JSON.stringify(chunk).slice(1, -1)); // retire les []
      if (i + chunkSize < asteroids.length) res.write(',');  // Ajoute la virgule si ce n'est pas le dernier
    }

    res.end(']');  // Fin du tableau JSON

  } catch (error) {
    console.error("Erreur de scraping:", error);
    res.status(500).json({ error: "Erreur de chargement des astéroïdes" });
  }
});

// Message personnalisé pour le serveur
app.listen(port, () => console.log('Serveur en cours sur https://asteroid-impact.glitch.me'));
