const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));
app.use(express.json());

// Sauvegarde de la configuration
app.post('/save-config', (req, res) => {
    const {
        rotationX, rotationY, rotationZ,
        positionX, positionY, positionZ,
        colors,
        triangles,
        labels,
        zoom,
      cameraZ
    } = req.body;

    const config = {
        rotationX, rotationY, rotationZ,
        positionX, positionY, positionZ,
        colors,
        triangles,
        labels,
        zoom,
      cameraZ
    };

    const configPath = path.join(__dirname, 'triangleConfig.json');
    fs.writeFile(configPath, JSON.stringify(config), (err) => {
        if (err) {
            console.error('Error saving configuration:', err);
            return res.status(500).send('Failed to save configuration');
        }
        res.send('Configuration saved');
    });
});

// Chargement de la configuration
app.get('/config', (req, res) => {
    const configPath = path.join(__dirname, 'triangleConfig.json');

    fs.readFile(configPath, 'utf8', (err, data) => {
        if (err) {
            if (err.code === 'ENOENT') {
                // Fichier non trouvé
                return res.json({});
            }
            console.error('Error loading configuration:', err);
            return res.status(500).send('Failed to load configuration');
        }
        res.json(JSON.parse(data));
    });
});

app.listen(PORT, () => {
    console.log(`Server is running on https://triangle3d.glitch.me`);
});
